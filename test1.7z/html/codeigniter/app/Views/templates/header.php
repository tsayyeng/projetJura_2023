<! doctype html>
<html>
<head>
<title>Codeigniter Tutorial</title>
</head>
<body>

<h1><?= esc($title) ?></h1>
