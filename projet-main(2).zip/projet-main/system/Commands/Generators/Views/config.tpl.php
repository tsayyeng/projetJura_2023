<@php

namespace {namespace};

use CodeIgniter\Config\BaseConfig;

class {class} extends BaseConfig
{
    //
}
